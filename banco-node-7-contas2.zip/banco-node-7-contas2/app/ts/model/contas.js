var Contas = /** @class */ (function () {
    function Contas() {
        this.contas = new Array();
        var c1 = new Conta('1', 100);
        var c2 = new Conta('2', 200);
        this.contas.push(c1, c2);
    }
    Contas.prototype.inserir = function (conta) {
        this.contas.push(conta);
    };
    Contas.prototype.remover = function (numero) {
        var contaARemover = this.pesquisar(numero);
        if (contaARemover) {
            var indiceConta = this.contas.indexOf(contaARemover);
            if (indiceConta > -1) {
                this.contas.splice(indiceConta, 1);
            }
        }
    };
    Contas.prototype.pesquisar = function (numero) {
        return this.contas.find(function (conta) { return conta.numero === numero; });
    };
    Contas.prototype.listar = function () {
        return this.contas;
    };
    return Contas;
}());
