class Clientes{
    private _clientes: Clientes[];
    getCpf: any;

    constructor(){
        this._clientes=[];
    }

    public inserir(cliente: Clientes) {
        this._clientes.push(cliente);
    }

    public remover(cpf: string){
        this._clientes=this._clientes.filter((cliente)=>cliente.getCpf() != cpf);
    }

    public listar(): Clientes[]{
        return this._clientes;
    }

    public pesquisar(cpf: string): Clientes | undefined {
        return this._clientes.find((cliente) => cliente.getCpf()===cpf);
    }
}