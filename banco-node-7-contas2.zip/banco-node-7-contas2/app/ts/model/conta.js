var Conta = /** @class */ (function () {
    function Conta(numero, saldo) {
        if (saldo === void 0) { saldo = 0; }
        this._numero = numero;
        this._saldo = saldo;
    }
    Object.defineProperty(Conta.prototype, "numero", {
        get: function () {
            return this._numero;
        },
        set: function (numero) {
            this._numero = numero;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Conta.prototype, "saldo", {
        get: function () {
            return this._saldo;
        },
        enumerable: false,
        configurable: true
    });
    Conta.prototype.debitar = function (valor) {
        //apenas debita se houver saldo
        if (valor < this._saldo) {
            this._saldo -= valor;
        }
    };
    Conta.prototype.creditar = function (valor) {
        this._saldo += valor;
    };
    Conta.prototype.transferir = function (valor, destino) {
        this.debitar(valor);
        destino.creditar(valor);
    };
    Conta.prototype.toString = function () {
        return "N\u00FAmero: ".concat(this._numero, " \n        - Saldo: ").concat(this._saldo);
    };
    return Conta;
}());
