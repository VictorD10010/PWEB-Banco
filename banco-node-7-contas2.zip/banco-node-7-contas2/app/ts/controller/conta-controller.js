var ContaController = /** @class */ (function () {
    function ContaController() {
        this.inputNumero =
            document.querySelector("#conta");
        this.inputSaldo =
            document.querySelector("#saldo");
        this.contas = new Contas();
    }
    ContaController.prototype.inserir = function (evento) {
        evento.preventDefault();
        var novaConta = new Conta(this.inputNumero.value, parseFloat(this.inputSaldo.value));
        this.contas.inserir(novaConta);
        this.inserirContaNoHTML(novaConta);
    };
    ContaController.prototype.listar = function () {
        var _this = this;
        this.contas.listar().forEach(function (conta) {
            _this.inserirContaNoHTML(conta);
        });
    };
    ContaController.prototype.inserirContaNoHTML = function (conta) {
        var _this = this;
        var elementoP = document.createElement('p');
        elementoP.textContent = conta.toString();
        var botaoApagar = document.createElement('button');
        botaoApagar.textContent = 'X';
        botaoApagar.addEventListener('click', function (event) {
            console.log('removendo conta ' + conta.toString());
            _this.contas.remover(conta.numero);
            event.target.parentElement.remove();
        });
        elementoP.appendChild(botaoApagar);
        document.body.appendChild(elementoP);
    };
    return ContaController;
}());
